// Cliente da API do MedCof dentro da extensao.
// O token fica no cookie `qbank_auth_token` (dominio .medcof.com.br), lido via chrome.cookies.
const API = "https://qbank-api.medcof.tech";
const COOKIE_URL = "https://qbank-prime.medcof.com.br";

export class TokenExpirado extends Error {
  constructor() {
    super("Sessão do MedCof expirada. Abra o MedCof no Chrome e faça login de novo.");
    this.code = "TOKEN_EXPIRADO";
  }
}

export async function medcofToken() {
  const c = await chrome.cookies.get({ url: COOKIE_URL, name: "qbank_auth_token" });
  if (!c || !c.value) {
    throw new TokenExpirado();
  }
  const payload = JSON.parse(atob(c.value.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")));
  if (payload.exp * 1000 < Date.now() + 60_000) throw new TokenExpirado();
  return { token: c.value, exp: payload.exp * 1000 };
}

async function api(path, token) {
  const r = await fetch(API + path, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
  });
  if (r.status === 401 || r.status === 403) throw new TokenExpirado();
  if (!r.ok) throw new Error(`MedCof ${r.status} em ${path}`);
  return r.json();
}

export async function listExams(token, pageSize = 100) {
  const all = [];
  for (let page = 1; page <= 200; page++) {
    const j = await api(
      `/v2/qbank/user/paginated?page=${page}&pageSize=${pageSize}&searchText=&dateFilterEnabled=false&dateFilter=&statusFilter=&reverseOrder=false`,
      token,
    );
    if (!j.data?.length) break;
    all.push(...j.data);
    if (j.data.length < pageSize) break;
  }
  return all;
}

export async function getExam(token, id) {
  const questions = [];
  let exam = null;
  for (let page = 1; page <= 30; page++) {
    const j = await api(`/v3/qbank/full/${id}?page=${page}&pageSize=100`, token);
    exam = j;
    questions.push(...(j.questions || []));
    if (!j.pagination || j.pagination.last) break;
  }
  return { ...exam, questions };
}
