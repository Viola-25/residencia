// Service worker: orquestra token MedCof + sessao do dashboard + gravacao.
import { medcofToken } from "./medcof.js";
import { auth, userId } from "./residencia.js";
import { buildPlan, commitPlan } from "./sync.js";

const STATE_KEY = "state";
const STATE_VERSION = 3;
const LOG_KEY = "lastLog";
let running = false;

function log(msg) {
  chrome.storage.local.set({ [LOG_KEY]: msg });
  chrome.runtime.sendMessage({ type: "log", msg }).catch(() => {});
}

async function loadState() {
  const { [STATE_KEY]: s } = await chrome.storage.local.get(STATE_KEY);
  const seed = await (await fetch(chrome.runtime.getURL("data/state.seed.json"))).json();
  const seedTemExames = seed.exams && Object.keys(seed.exams).length > 0;

  if (s && s.version === STATE_VERSION) {
    if (Object.keys(s.exams || {}).length === 0 && seed.version === STATE_VERSION && seedTemExames) {
      await chrome.storage.local.set({ [STATE_KEY]: seed });
      return seed;
    }
    return s;
  }

  const fresh =
    seed.version === STATE_VERSION
      ? seed
      : { version: STATE_VERSION, baselineAt: seed.baselineAt || null, exams: {} };
  await chrome.storage.local.set({ [STATE_KEY]: fresh });
  return fresh;
}

const saveState = (s) => chrome.storage.local.set({ [STATE_KEY]: s });

async function loadTags() {
  return (await fetch(chrome.runtime.getURL("data/tags.json"))).json();
}

async function run({ commit }) {
  if (running) throw new Error("Já tem um sync rodando. Espere terminar.");
  running = true;
  try {
    log("Lendo sessão do MedCof...");
    const { token } = await medcofToken();
    log("MedCof: sessão OK.");

    log("Lendo sessão do dashboard...");
    const session = await auth();
    const uid = userId(session);

    const state = await loadState();
    const tags = await loadTags();

    const { plan, unresolvedAreas, remaining, batch, pending } = await buildPlan({
      token,
      session,
      uid,
      state,
      tags,
      onProgress: log,
    });

    if (!plan.length) {
      await saveState(state);
      log(
        remaining > 0
          ? `Nenhum teste com respostas neste lote. Restam ${remaining}. Clique Sincronizar de novo.`
          : "Nada novo. Dashboard já está em dia com o MedCof.",
      );
      return { plan: [], nLogs: 0, nErrors: 0, nadaNovo: true, remaining };
    }

    const resumo = plan.map((p) => ({
      date: p.dailyRow.date,
      questoes: p.dailyRow.questions_done,
      acertos: Math.round((p.dailyRow.hit_rate / 100) * p.dailyRow.questions_done),
      hit: p.dailyRow.hit_rate,
      erros: p.errors.length,
      reincidencias: (p.repeats || []).length,
      nome: p.dailyRow.notes,
      jaExiste: p.already,
    }));

    if (!commit) {
      await saveState(state);
      return {
        plan: resumo,
        nLogs: 0,
        nErrors: 0,
        preview: true,
        semArea: Object.keys(unresolvedAreas || {}).length,
        remaining,
        batch,
        pending,
      };
    }

    const { nLogs, nErrors, nRepeats } = await commitPlan({ plan, session, state, saveState, onProgress: log });
    log(
      `Pronto: ${nLogs} rodada(s), ${nErrors} erro(s) novo(s), ${nRepeats} reincidência(s).` +
        (remaining > 0 ? ` Restam ${remaining} testes — clique Sincronizar de novo.` : ""),
    );
    return {
      plan: resumo,
      nLogs,
      nErrors,
      nRepeats,
      semArea: Object.keys(unresolvedAreas || {}).length,
      remaining,
      batch,
      pending,
    };
  } finally {
    running = false;
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "run") {
    run({ commit: !!msg.commit })
      .then((r) => sendResponse({ ok: true, ...r }))
      .catch((e) => {
        log("Erro: " + e.message);
        sendResponse({ ok: false, error: e.message, code: e.code || null });
      });
    return true; // resposta assincrona
  }
  if (msg?.type === "resetState") {
    chrome.storage.local.remove([STATE_KEY, "session", LOG_KEY]).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "info") {
    loadState()
      .then((state) =>
        chrome.storage.local.get([LOG_KEY, "session"]).then((d) =>
          sendResponse({
            ok: true,
            exames: Object.keys(state.exams || {}).length,
            baselineAt: state.baselineAt || null,
            estadoVersao: state.version,
            versao: chrome.runtime.getManifest().version,
            lastLog: d[LOG_KEY] || null,
            temSessao: !!d.session,
          }),
        ),
      )
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

// primeiro uso: carrega o estado inicial (baseline) sem importar historico
chrome.runtime.onInstalled.addListener(() => {
  loadState().catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  loadState().catch(() => {});
});
