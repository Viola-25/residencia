// Cliente do Supabase dentro da extensao: usa a sessao do dashboard logado.
// Regra: NUNCA rotaciona a sessao sem devolver o token novo para a aba do site
// (o Supabase rotaciona o refresh_token e a aba ficaria deslogada).
import { SUPABASE_URL, SUPABASE_ANON, SITE_URL } from "./config.js";

const AUTH_STORAGE_KEY = "session";

async function getSession() {
  const { [AUTH_STORAGE_KEY]: s } = await chrome.storage.local.get(AUTH_STORAGE_KEY);
  return s || null;
}

async function setSession(s) {
  await chrome.storage.local.set({ [AUTH_STORAGE_KEY]: s });
}

function acharAbaDoSite() {
  return chrome.tabs.query({ url: `${SITE_URL}/*` }).then((tabs) => tabs.find((t) => t.status === "complete") || tabs[0]);
}

async function lerDoSite(tabId) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const k = Object.keys(localStorage).find((k) => k.startsWith("sb-") && k.endsWith("-auth-token"));
      return k ? { key: k, raw: localStorage.getItem(k) } : null;
    },
  });
  return res?.result || null;
}

async function escreverNoSite(tabId, key, value) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (k, v) => localStorage.setItem(k, v),
    args: [key, value],
  });
}

// Pega a sessao direto da aba logada do dashboard (nao rotaciona nada).
export async function captureSession() {
  let tab = await acharAbaDoSite();
  let criada = false;
  if (!tab) {
    tab = await chrome.tabs.create({ url: `${SITE_URL}/desempenho`, active: false });
    criada = true;
  }
  let lido = null;
  for (let i = 0; i < 40 && !lido; i++) {
    try {
      lido = await lerDoSite(tab.id);
    } catch {
      // aba ainda carregando
    }
    if (!lido) await new Promise((r) => setTimeout(r, 300));
  }
  if (criada) chrome.tabs.remove(tab.id).catch(() => {});
  if (!lido) {
    throw new Error("Sem sessão no dashboard. Abra residencia-cyan.vercel.app, faça login e tente de novo.");
  }
  const s = JSON.parse(lido.raw);
  const session = {
    access_token: s.access_token,
    refresh_token: s.refresh_token,
    expires_at: s.expires_at || Math.floor(Date.now() / 1000) + 3600,
  };
  await setSession(session);
  return session;
}

async function renovar(session) {
  const r = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: { apikey: SUPABASE_ANON, "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: session.refresh_token }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.access_token) {
    // token ja usado por outra aba -> recaptura do site
    return captureSession();
  }
  const nova = { access_token: j.access_token, refresh_token: j.refresh_token, expires_at: j.expires_at };
  await setSession(nova);
  // devolve para a aba do site para ela nao ser deslogada
  try {
    const tab = await acharAbaDoSite();
    if (tab) {
      const lido = await lerDoSite(tab.id);
      if (lido) {
        const atual = JSON.parse(lido.raw);
        await escreverNoSite(
          tab.id,
          lido.key,
          JSON.stringify({ ...atual, access_token: nova.access_token, refresh_token: nova.refresh_token, expires_at: nova.expires_at }),
        );
      }
    }
  } catch {
    // sem aba aberta: a proxima rodada recaptura
  }
  return nova;
}

export async function auth() {
  let s = (await getSession()) || (await captureSession());
  if ((s.expires_at || 0) * 1000 < Date.now() + 60_000) s = await renovar(s);
  return s;
}

function headers(session, extra = {}) {
  return {
    apikey: SUPABASE_ANON,
    Authorization: `Bearer ${session.access_token}`,
    "Content-Type": "application/json",
    ...extra,
  };
}

async function req(method, path, session, body, extra = {}) {
  let r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method,
    headers: headers(session, extra),
    body: body ? JSON.stringify(body) : undefined,
  });
  if (r.status === 401) {
    const nova = await renovar(session);
    r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
      method,
      headers: headers(nova, extra),
      body: body ? JSON.stringify(body) : undefined,
    });
  }
  const t = await r.text();
  if (!r.ok) throw new Error(`Supabase ${method} ${path.split("?")[0]}: ${r.status} ${t.slice(0, 300)}`);
  return t ? JSON.parse(t) : null;
}

export const select = (table, query, session) => req("GET", `${table}?${query}`, session);
export const insert = (table, rows, session) =>
  req("POST", table, session, rows, { Prefer: "return=representation" });
export const update = (table, query, values, session) =>
  req("PATCH", `${table}?${query}`, session, values, { Prefer: "return=representation" });

export function userId(session) {
  return JSON.parse(atob(session.access_token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))).sub;
}
