// Classifica tema do MedCof -> grande area usada no dashboard.
// Ordem: override manual > sufixo do tema > palavra-chave > voto dos irmaos (mesmo pai).

export const AREAS = {
  clinica_medica: "Clínica Médica",
  cirurgia: "Cirurgia",
  pediatria: "Pediatria",
  ginecologia_obstetricia: "Ginecologia e Obstetrícia",
  preventiva: "Preventiva / Saúde Coletiva",
};

const SUFFIX = {
  CM: "clinica_medica",
  CIR: "cirurgia",
  PED: "pediatria",
  GO: "ginecologia_obstetricia",
  GOB: "ginecologia_obstetricia",
  GIN: "ginecologia_obstetricia",
  URO: "cirurgia",
  PREV: "preventiva",
  MFC: "preventiva",
  SP: "preventiva",
};

const SUFFIX_RE = /\(([A-Z][A-Z. ]{1,12})\)\s*$/;

// Regras por palavra-chave. A primeira que casar vence.
const RULES = [
  ["ginecologia_obstetricia", [
    "gineco", "obstetr", "gesta", "prenatal", "pré-natal", "parto", "puerp", "aborto",
    "vagina", "vulva", "colo do utero", "colo do útero", "colpocito", "endometri", "ovari",
    "mama", "mamari", "amenorreia", "sangramento uterino", "anticoncep", "contracep",
    "climaterio", "climatério", "menopausa", "infertil", "leiomioma", "mioma", "adenomiose",
    "endometriose", "hpv", "eclampsia", "eclâmpsia", "placenta", "cesarea", "cesárea",
    "histerectomia", "histeroscopia", "corrimento", "vaginose", "candidiase", "candidíase",
    "ovariano", "policistico", "policístico", "uroginecologia", "prolapso", "dst", "ist ",
    "gravidez", "puerperio", "puerpério", "amniot", "trabalho de parto", "pelve feminina",
    "citologia onc", "rastreamento de cancer de colo", "colo de utero", "colo de útero",
    "somp", "hiperprolactinem", "puberdade", "pelvica inflamatoria", "pélvica inflamatória",
    "inflamatoria pelvica", "inflamatória pélvica",
    "papilar", "donovanose", "incontinencia urinaria", "incontinência urinária", "iuu",
    "desenvolvimento sexual", "amenorreia", "sangramento uterino anormal", "hirsutismo",
  ]],
  ["pediatria", [
    "pediatr", "pediátr", "neonat", "recem-nascido", "recém-nascido", "lactente", "crianca",
    "criança", "infantil", "aleitamento", "amamenta", "puericultura", "crescimento",
    "desenvolvimento neuropsicomotor", "ictericia neonatal", "icterícia neonatal",
    "bronquiolite", "croup", "laringite", "epiglotite", "exantema", "sarampo", "varicela",
    "caxumba", "rubeola", "rubéola", "febre reumatica", "febre reumática",
    "cardiopatia congenita", "cardiopatia congênita", "pezinho", "triagem neonatal",
    "desidratacao", "desidratação", "diarreia aguda", "refluxo gastroesofagico",
  ]],
  ["cirurgia", [
    "cirurgi", "apendic", "colecist", "hernia", "hérnia", "trauma", "queimadur",
    "pre-operatorio", "pré-operatório", "pos-operatorio", "pós-operatório", "anestes",
    "laparotomia", "laparoscopia", "toracic", "torácic", "vascular", "aneurisma",
    "mesenteric", "obstrucao intestinal", "obstrução intestinal", "abdome agudo",
    "prostata", "próstata", "litíase", "litiase", "urolog", "bexiga", "hidrocele",
    "varicocele", "ortoped", "fratura", "luxacao", "luxação", "neurocirurgia",
    "transplante", "drenagem", "sutura", "colonoscopia", "endoscopia digestiva alta",
    "hemorroid", "fissura anal", "colecistite", "pancreatite", "tiroide", "tireoide",
    "bocio", "bócio", "mastologia cirurgic", "cirurgia do aparelho digestivo",
    "vesicula", "vesícula", "vias biliares", "hemorragia digestiva", "coledoco", "colédoco",
  ]],
  ["preventiva", [
    "preventiva", "saude publica", "saúde pública", "sus", "atencao primaria",
    "atenção primária", "aps", "epidemiolog", "rastreamento", "vacin", "vigilancia",
    "vigilância", "notificacao", "notificação", "bioestatistica", "bioestatística",
    "estatistica", "estatística", "etica medic", "ética médic", "bioetica", "bioética",
    "medicina legal", "saude da familia", "saúde da família", "mfc", "politicas publicas",
    "políticas públicas", "hanseniase", "hanseníase", "saneamento", "indicadores de saude",
    "indicadores de saúde", "programa nacional de imuniza", "pni", "tabulacao", "tabulação",
    "prep", "pep", "profilaxia pos-exposicao", "profilaxia pós-exposição", "calendario vacinal",
    "calendário vacinal", "mortalidade", "incidencia", "incidência", "prevalencia", "prevalência",
  ]],
  ["clinica_medica", [
    "cardiolog", "pneumolog", "gastro", "hepat", "nefrolog", "endocrin", "diabete",
    "neurolog", "psiquiatr", "reumatolog", "hematolog", "infectolog", "dermatolog",
    "oftalmolog", "otorrino", "clinic", "clínic", "hipertens", "insuficiencia cardiaca",
    "insuficiência cardíaca", "arritmia", "sepse", "choque", "pneumonia", "dpoc", "asma",
    "tuberculose", "hiv", "sifilis", "sífilis", "dengue", "malaria", "malária",
    "tireoid", "obesidade", "dislipidemia", "avc", "epilepsia", "demencia", "demência",
    "depressao", "depressão", "ansiedade", "lupus", "lúpus", "artrite", "anemia",
    "leucemia", "linfoma", "coagulac", "coagulaç", "acidose", "disturbio hidroeletrolitico",
  ]],
];

const EXTRA = {
  ginecologia_obstetricia: [
    "rciu", "sofrimento fetal", "dopplervelocimetria", "colo curto", "rpmo", "corioamnionite",
    "gemelaridade", "cerclagem", "neuroprotecao", "neuroproteção", "maturacao pulmonar",
    "maturação pulmonar", "prematuridade", "hemolitica perinatal", "hemolítica perinatal",
    "mola hidatiforme", "mullerian", "asherman", "dismenorreia", "sua por", "causas nao estruturais",
    "fecundidade", "pop-q", "iue", "esfincteriano", "leopold", "egb", "estrepitococo", "estreptococo",
    "herpes simples genital", "ulceras genitais", "úlceras genitais", "mastite", "iota", "orads",
    "anexiais", "colo uterino", "dor pelvica cronica", "dor pélvica crônica", "morris",
    "bartholin", "sangramento uterino", "suplementacao hormonal", "tamoxifeno", "endometriose",
    "histeroscopia", "laqueadura", "diu", "implante contraceptivo", "puerperio", "loquios",
  ],
  pediatria: [
    "enterocolite necrotizante", "turner", "triagem neonatal", "teste do pezinho",
    "ictericia", "icterícia", "kernicterus", "sepsis neonatal", "sepse neonatal",
    "hipoglicemia neonatal", "malformacao anorretal", "malformação anorretal",
    "atresia de esofago", "atresia de esôfago", "onfalocele", "gastrosquise",
    "refluxo vesicoureteral", "valva de uretra posterior", "hipospadia", "criptorquidia",
    "escarlatina", "coqueluche", "meningite neonatal", "sindrome de down", "síndrome de down",
  ],
  cirurgia: [
    "pos-operatori", "pós-operatóri", "perioperatori", "perioperatóri", "retalho", "queimad",
    "cicatriz", "cicatriza", "queloide", "quelóide", "deiscencia", "deiscência",
    "pancreas", "pâncreas", "estomago", "estômago", "gastrectomia", "meckel", "bridas",
    "ogilvie", "ileo biliar", "íleo biliar", "volvo", "diverticulite", "forrest",
    "mallory-weiss", "colorretal", "cancer de reto", "câncer de reto", "anorretal",
    "boerhaave", "perfuracao esofagica", "perfuração esofágica", "ferimento abdominal",
    "xabcd", "triade letal", "tríade letal", "mediastino", "timoma", "torcao testicular",
    "torção testicular", "orquiepididimite", "priapismo", "prostatica", "prostática",
    "hpb", "miccionais", "desobstrucao de urgencia", "desobstrução de urgência",
    "hipospadia", "arterial obstrutiva", "isquemia critica", "isquemia crítica",
    "obstrucao arterial", "ceap", "sarcoma", "breslow", "malignos de pele",
    "colangiografia", "bariatrica", "bariátrica", "terapia nutricional", "asa do estado",
    "capnografia", "sedacao e analgesia", "sedação e analgesia", "orofaringe", "laringe",
    "massas cervicais", "cancer primario oculto", "câncer primário oculto",
    "nutricao perioperatoria", "nutrição perioperatória", "complicacoes pos",
    "complicações pós", "herniorrafia", "gastrostomia", "esplenectomia", "tireoidectomia",
    "glasgow", "colangiocarcinoma", "insuficiencia venosa", "insuficiência venosa",
    "terapia expulsiva", "nervos da regiao inguinal", "nervos da região inguinal",
    "medidas iniciais no tce", "medidas inicias no tce", "anorreta", "politrauma",
    "hdb", "hemorragia digestiva baixa", "hemorragia digestiva alta",
    "glandulas salivares", "glândulas salivares", "salivar", "parotida", "parótida",
  ],
  preventiva: [
    "determinantes sociais", "redes de atencao", "redes de atenção", "niveis de prevencao",
    "níveis de prevenção", "prevencao quaternaria", "prevenção quaternária", "quinquenaria",
    "quinquenária", "promocao a saude", "promoção à saúde", "saude privada", "saúde privada",
    "protecao social", "proteção social", "atencao basica", "atenção básica",
    "pacto pela saude", "pacto pela saúde", "lei 8.142", "decreto 7.508", "saude lgbt",
    "saúde lgbt", "saude indigena", "saúde indígena", "saude prisional", "saúde prisional",
    "populacao negra", "população negra", "populacao de rua", "população de rua",
    "judicializacao", "judicialização", "violencia sexual", "violência sexual",
    "educacao em saude", "educação em saúde", "projeto terapeutico singular",
    "projeto terapêutico singular", "telemedicina", "processo epidemico", "processo epidêmico",
    "associacao e causalidade", "associação e causalidade", "sensibilidade", "especificidade",
    "valores preditivos", "vieses", "estudo transversal", "caso-controle", "ecologico",
    "ecológico", "risco relativo", "risco atribuivel", "risco atribuível", "reducao absoluta",
    "redução absoluta", "reducao de risco", "redução de risco", "nnt", "odds ratio",
    "hazard ratio", "razao de verossimilhanca", "razão de verossimilhança", "curva roc",
    "acuracia", "acurácia", "testes diagnosticos", "testes diagnósticos", "niveis de evidencia",
    "níveis de evidência", "baseada em evidencias", "baseada em evidências", "fases do ecr",
    "randomizacao", "randomização", "pico", "desfechos em ecr", "etica em pesquisa",
    "ética em pesquisa", "principios bioeticos", "princípios bioéticos", "sigilo medico",
    "sigilo médico", "documentos medicos", "documentos médicos", "receitas medicas",
    "receitas médicas", "publicidade medica", "publicidade médica", "spikes", "luto",
    "burnout", "saude planetaria", "saúde planetária", "socioecologica", "socioecológica",
    "vulnerabilidade", "modelos explicativos", "diagrama de controle", "indicadores de morbidade",
    "daly", "eficacia efetividade", "eficácia efetividade", "sobrediagnostico", "sobrediagnóstico",
    "ocupacionais", "acidentes de trabalho", "cat", "ler dort", "visao critica de seguranca",
    "profilaxias", "niveis de atencao", "níveis de atenção", "mccp", "remit", "nobs", "dart",
    "saude coletiva", "saúde coletiva", "medicina de familia", "prevencao", "prevenção",
    "rastreamento populacional", "vigilancia epidemiologica", "vigilância epidemiológica",
    "lei 8 080", "lei 8080", "declaracao de obito", "declaração de óbito",
    "metanalise", "metanálise", "revisao sistematica", "revisão sistemática",
  ],
  clinica_medica: [
    "psicotic", "psicótic", "tabagismo", "paralisia facial", "psicofarmacolog",
    "involuntaria", "involuntária", "uso de alcool", "uso de álcool", "uso de substancias",
    "uso de substâncias", "ansios", "depressiv", "maniac", "maníac", "somatoform",
    "alimentares", "pulmao", "pulmão", "hemoptise", "bronquiectas", "traqueai", "traqueal",
    "pneumoconiose", "schilling", "chc", "disquesia", "hipertensao portal", "ascite",
    "encefalopatia", "hepatite", "cirrose", "doenca renal", "doença renal", "dialise",
    "diálise", "sindrome nefrotica", "síndrome nefrótica", "glomerulonefrite",
    "disturbios acidos", "distúrbios ácidos", "hipercalemia", "hiponatremia",
    "insuficiencia respiratoria", "insuficiência respiratória", "ventilacao mecanica",
    "ventilação mecânica", "tep", "tromboembolismo", "fibrilacao", "fibrilação",
    "sincope", "síncope", "endocardite", "valvopatia", "pericardite", "miocardite",
    "amiloidose", "vasculite", "esclerose", "parkinson", "cefaleia", "migranea", "migrânea",
    "avc isquemico", "avc isquêmico", "hemorragia intracraniana", "meningite", "encefalite",
    "sifilis", "sífilis", "gonorreia", "clamidia", "clâmídia", "herpes zoster",
    "covid", "influenza", "arbovirose", "chikungunya", "zika", "febre amarela",
    "leishmaniose", "doenca de chagas", "doença de chagas", "esquistossomose",
    "verminose", "anemia ferropriva", "anemia megaloblastica", "anemia megaloblástica",
    "trombocitopenia", "hemofilia", "anticoagulac", "anticoagulaç", "tireoide",
    "sindrome metabolica", "síndrome metabólica", "osteoporose", "gota", "artrose",
    "fibromialgia", "espondilite", "psoriase", "psoríase", "dermatite", "melanoma",
    "insuficiencia cardiaca", "insuficiência cardíaca", "arritmia", "angina",
    "sindrome coronariana", "síndrome coronariana", "dor toracica", "dor torácica",
    "suicidio", "suicídio", "nodulo pulmonar",
    "nódulo pulmonar", "pequenas celulas", "pequenas células", "anatomia neuro",
    "dermatopatologia", "uso do alcool", "uso do álcool",
  ],
};

// Junta base + extras mantendo a ordem de prioridade das areas.
const AREA_RULES = RULES.map(([area, words]) => [area, [...words, ...(EXTRA[area] || [])]]);

const PREFIX_RULES = [
  [/^clinica medica/, "clinica_medica"],
  [/^cirurgia/, "cirurgia"],
  [/^pediatria/, "pediatria"],
  [/^(ginecologia|go)\b/, "ginecologia_obstetricia"],
  [/^(preventiva|saude coletiva|medicina preventiva|medicina social)/, "preventiva"],
];

const normalize = (s) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

export function cleanTopic(name) {
  return String(name || "").replace(/\s*\([A-Z][A-Z. ]{1,12}\)\s*$/, "").trim();
}

export function classifyTag(tag, allTags = {}) {
  if (!tag) return null;
  const name = tag.name || "";

  const suffix = String(name).match(SUFFIX_RE);
  if (suffix) {
    const known = SUFFIX[suffix[1].trim().replace(/\./g, "").toUpperCase()];
    if (known) return known;
  }

  // Prefixo explicito no nome do tema ("Clínica Médica - X", "Pediatria - Y") manda mais
  // que palavra-chave: e a propria taxonomia da plataforma.
  const prefixed = PREFIX_RULES.find(([re]) => re.test(normalize(name)));
  if (prefixed) return prefixed[1];

  const n = normalize(cleanTopic(name));
  for (const [area, words] of AREA_RULES) {
    if (words.some((w) => n.includes(normalize(w)))) return area;
  }

  // Sem pista no nome: vota com os irmaos (mesmo pai) que ja foram classificados.
  if (tag.parentIdentifier) {
    const siblings = Object.values(allTags).filter(
      (t) => t.parentIdentifier === tag.parentIdentifier && t.name !== name,
    );
    const votes = {};
    for (const s of siblings) {
      const a = classifyByNameOnly(s.name);
      if (a) votes[a] = (votes[a] || 0) + 1;
    }
    const ranked = Object.entries(votes).sort((a, b) => b[1] - a[1]);
    const total = ranked.reduce((s, [, v]) => s + v, 0);
    if (ranked.length && total >= 2 && ranked[0][1] / total >= 0.6) return ranked[0][0];
  }
  return null;
}

function classifyByNameOnly(name) {
  return classifyTag({ name });
}
