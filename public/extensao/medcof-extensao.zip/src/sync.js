// Nucleo do sync (mesma logica de scripts/sync.mjs), adaptado para rodar na extensao.
import { listExams, getExam } from "./medcof.js";
import { select, insert, update } from "./residencia.js";
import { classifyTag, cleanTopic } from "./areas.js";

const TZ_OFFSET_H = -3; // America/Sao_Paulo (sem horario de verao)

const localDate = (iso) => new Date(new Date(iso).getTime() + TZ_OFFSET_H * 3600e3).toISOString().slice(0, 10);
const round = (n, d = 2) => Math.round(n * 10 ** d) / 10 ** d;
const stripHtml = (s) => String(s || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();

const questionType = (q) => {
  const nome = String(q.typeOfTestName || "");
  if (/acesso direto/i.test(nome)) return "direto";
  if (/^R\+/i.test(nome.trim())) return "rplus";
  return "outros";
};

const areaKey = (areas) => [...new Set((areas || []).map((a) => a.area).filter(Boolean))].sort().join("+");
const sig = (d, q, h, a) => `${d}|${q}|${Number(h).toFixed(2)}|${a}`;

const BATCH_SIZE = 150;
const EXAM_DELAY_MS = 200;
const DEFAULT_WINDOW_DAYS = 7;
const WINDOW_OPTIONS = [7, 14, 30];
const DAY_MS = 86_400_000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function buildPlan({
  token,
  session,
  uid,
  state,
  tags,
  onProgress = () => {},
  limit = BATCH_SIZE,
  windowDays = DEFAULT_WINDOW_DAYS,
}) {
  const exams = (await listExams(token)).filter((e) => e.status === "FINISHED");
  exams.sort((a, b) => new Date(a.updatedAt || a.createdAt) - new Date(b.updatedAt || b.createdAt));

  const dias = WINDOW_OPTIONS.includes(Number(windowDays)) ? Number(windowDays) : DEFAULT_WINDOW_DAYS;
  const windowStart = Date.now() - dias * DAY_MS;
  const lastSyncMs = state.lastSyncAt ? new Date(state.lastSyncAt).getTime() : NaN;
  const rangeStart = Number.isFinite(lastSyncMs) ? Math.min(windowStart, lastSyncMs) : windowStart;
  const rangeIso = new Date(rangeStart).toISOString();

  const pending = exams.filter((e) => {
    if (state.exams?.[e.identifier]) return false;
    const ts = new Date(e.updatedAt || e.createdAt).getTime();
    return Number.isFinite(ts) && ts >= rangeStart;
  });
  const batch = pending.slice(0, limit);
  onProgress(
    `MedCof: ${exams.length} finalizados, ${pending.length} novos na janela de ${dias}d. Lendo ${batch.length} neste lote...`,
  );
  if (!batch.length) {
    return {
      plan: [],
      pending: 0,
      total: exams.length,
      remaining: 0,
      batch: 0,
      rangeStart: rangeIso,
      windowDays: dias,
    };
  }

  const dailyLogs = await select("daily_logs", `select=date,questions_done,hit_rate,areas_data&user_id=eq.${uid}`, session);
  const errorBank = await select("error_bank", `select=id,question,occurrence_count,history_notes,question_identifier&user_id=eq.${uid}`, session);
  const existingLogs = new Set(dailyLogs.map((r) => sig(r.date, r.questions_done, r.hit_rate, areaKey(r.areas_data))));
  const fingerprint = (text) => stripHtml(text).slice(0, 120).toLowerCase();
  const existingErrors = new Map(errorBank.map((r) => [fingerprint(r.question), r]));
  const existingByIdentifier = new Map(
    errorBank.filter((r) => r.question_identifier).map((r) => [r.question_identifier, r]),
  );

  const plan = [];
  const unresolvedAreas = {};

  for (const meta of batch) {
    onProgress(`Lendo ${meta.name}...`);
    const exam = await getExam(token, meta.identifier);
    const answered = exam.questions.filter((q) => q.answered && q.answered.answerId);
    if (!answered.length) {
      state.exams[meta.identifier] = {
        name: meta.name,
        date: localDate(meta.updatedAt || meta.createdAt),
        imported: false,
        reason: "sem respostas",
      };
      continue;
    }

    const right = answered.filter((q) => q.answered.wasRight).length;
    const when = exam.updatedAt || exam.createdAt;
    const date = localDate(when);
    const hit = round((right / answered.length) * 100);

    const areas = {};
    const diff = { EASY: [0, 0], MEDIUM: [0, 0], HARD: [0, 0] };
    const qtypes = {};
    let srSum = 0;
    let srN = 0;

    for (const q of answered) {
      const ok = q.answered.wasRight === true;
      const tag = (q.tags || [])[0];
      const area = classifyTag(tag, tags);
      if (!area) {
        const key = tag?.name || "(sem tema)";
        unresolvedAreas[key] = (unresolvedAreas[key] || 0) + 1;
      }
      const bucket = (areas[area || "sem_area"] ||= { correct: 0, questions_done: 0 });
      bucket.questions_done++;
      if (ok) bucket.correct++;

      const d = q.difficultyStats?.difficulty || "MEDIUM";
      diff[d] ||= [0, 0];
      diff[d][1]++;
      if (ok) diff[d][0]++;

      const tipo = questionType(q);
      const tb = (qtypes[tipo] ||= { q: 0, c: 0, srSum: 0, srN: 0 });
      tb.q++;
      if (ok) tb.c++;
      if (q.difficultyStats?.successRate != null) {
        tb.srSum += q.difficultyStats.successRate;
        tb.srN++;
      }

      if (q.difficultyStats?.successRate != null) {
        srSum += q.difficultyStats.successRate;
        srN++;
      }
    }

    const questionTypes = Object.fromEntries(
      Object.entries(qtypes).map(([tipo, v]) => [
        tipo,
        { q: v.q, c: v.c, avg: v.srN ? round((v.srSum / v.srN) * 100, 1) : null },
      ]),
    );

    const platformAvg = srN ? round((srSum / srN) * 100, 1) : null;

    const already = existingLogs.has(
      sig(date, answered.length, hit, areaKey(Object.keys(areas).filter((a) => a !== "sem_area").map((a) => ({ area: a })))),
    );

    const examName = String(exam.name || meta.name || "MedCof").trim();
    const isRevisaoNucleo = /revis[ãa]o\s+(express|n[úu]cleo)/i.test(examName);

    const dailyRow = {
      user_id: uid,
      date,
      hours_studied: round((exam.elapsedTime || 0) / 3600, 2),
      questions_done: answered.length,
      hit_rate: hit,
      core_review_done: false,
      flashcards_done: false,
      notes: isRevisaoNucleo ? "Revisão Núcleo" : examName.slice(0, 180),
      mood: "bom",
      energy_level: 7,
      created_at: when,
      registration_type: isRevisaoNucleo ? "revisao" : "questoes",
      areas_data: Object.entries(areas)
        .filter(([a]) => a !== "sem_area")
        .map(([area, v]) => ({ area, correct: v.correct, questions_done: v.questions_done })),
      platform_avg_rate: platformAvg,
      score_delta: platformAvg == null ? null : round(hit - platformAvg, 1),
      question_types: questionTypes,
      easy_correct: diff.EASY?.[0] ?? 0,
      easy_total: diff.EASY?.[1] ?? 0,
      medium_correct: diff.MEDIUM?.[0] ?? 0,
      medium_total: diff.MEDIUM?.[1] ?? 0,
      hard_correct: diff.HARD?.[0] ?? 0,
      hard_total: diff.HARD?.[1] ?? 0,
      platform_total_questions: answered.length,
      time_spent_minutes: Math.round((exam.elapsedTime || 0) / 60),
      name: null,
      ranking: null,
      participants: null,
    };

    if (already) {
      plan.push({ meta, dailyRow, errors: [], repeats: [], already });
      await sleep(EXAM_DELAY_MS);
      continue;
    }

    const errors = [];
    const repeats = new Map();
    for (const q of answered) {
      if (q.answered.wasRight !== false) continue;
      const chosen = (q.answers || []).find((a) => a.answerId === q.answered.answerId);
      const correta = (q.answers || []).find((a) => a.rightAnswer);
      const questionText = stripHtml(q.statement).trim();
      const qid = q.questionIdentifier != null ? String(q.questionIdentifier) : null;
      const fp = fingerprint(questionText);
      const prev = (qid && existingByIdentifier.get(qid)) || existingErrors.get(fp);

      const questionTags = (q.tags || []).map((t) => t.name).filter(Boolean);
      const snapshot = {
        statement_html: q.statement || null,
        alternatives: (q.answers || []).map((a, i) => ({
          id: String(a.answerId),
          letter: String.fromCharCode(65 + i),
          text: a.answer,
          comment: a.comment || null,
          is_correct: a.rightAnswer === true,
        })),
        correct_answer_id: correta ? String(correta.answerId) : null,
        chosen_answer_id: chosen ? String(chosen.answerId) : null,
        tags: questionTags,
        question_identifier: qid,
        exam_name: examName,
        exam_identifier: exam.identifier || meta.identifier || null,
        institution: q.institutionName || null,
        question_year: q.year != null ? String(q.year) : null,
        take_home_message: q.takeHomeMessage || null,
        overall_comment: q.comment || null,
        platform_difficulty: q.difficultyStats?.difficulty || null,
        success_rate: q.difficultyStats?.successRate ?? null,
      };

      if (prev) {
        if (!prev.id) continue;
        const key = qid || fp;
        const r = repeats.get(key) || {
          id: prev.id,
          count: prev.occurrence_count || 1,
          notes: Array.isArray(prev.history_notes) ? [...prev.history_notes] : [],
          snapshot,
        };
        r.count += 1;
        r.notes.push(`Reincidência em ${date}`);
        r.snapshot = snapshot;
        repeats.set(key, r);
        continue;
      }
      existingErrors.set(fp, { id: null, occurrence_count: 1 });
      if (qid) existingByIdentifier.set(qid, { id: null, occurrence_count: 1 });

      const tag = (q.tags || [])[0];
      errors.push({
        user_id: uid,
        question: questionText,
        topic: cleanTopic(tag?.name) || "Sem tema",
        subtopic: null,
        error_reason: "Não sabia",
        needs_review: false,
        reviewed: false,
        created_at: when,
        origem_atividade: null,
        nivel_confianca: "baixo",
        recorrencia: 1,
        ultima_ocorrencia: date,
        sugestao_revisao: null,
        area: classifyTag(tag, tags),
        next_review_date: new Date().toISOString(),
        interval_days: 1,
        ease_factor: 2.5,
        repetitions: 0,
        occurrence_count: 1,
        ...snapshot,
        history_notes: [
          q.statement,
          ...(chosen ? [`Marquei errada: ${chosen.answer}`] : []),
          ...(correta ? [`Correta: ${correta.answer}`] : []),
        ],
        flashcard_front: null,
        flashcard_back: null,
      });
    }

    plan.push({ meta, dailyRow, errors, repeats: [...repeats.values()], already });
    await sleep(EXAM_DELAY_MS);
  }

  return {
    plan,
    pending: pending.length,
    total: exams.length,
    batch: batch.length,
    remaining: Math.max(0, pending.length - batch.length),
    rangeStart: rangeIso,
    windowDays: dias,
    unresolvedAreas,
  };
}

// Grava: erros primeiro (idempotentes por enunciado), rodada depois. Salva o state a cada teste.
export async function commitPlan({ plan, session, state, saveState, onProgress = () => {} }) {
  let nLogs = 0;
  let nErrors = 0;
  let nRepeats = 0;

  for (const p of plan) {
    if (p.errors.length) {
      const saved = await insert("error_bank", p.errors, session);
      nErrors += saved.length;
    }
    for (const r of p.repeats || []) {
      await update(
        "error_bank",
        `id=eq.${r.id}`,
        {
          occurrence_count: r.count,
          recorrencia: r.count,
          ultima_ocorrencia: p.dailyRow.date,
          next_review_date: new Date().toISOString(),
          reviewed: false,
          interval_days: 1,
          repetitions: 0,
          history_notes: r.notes,
          ...(r.snapshot || {}),
        },
        session,
      );
      nRepeats++;
    }
    let logId = null;
    if (!p.already) {
      const [log] = await insert("daily_logs", [p.dailyRow], session);
      logId = log?.id ?? null;
      nLogs++;
    }
    state.exams[p.meta.identifier] = {
      name: p.meta.name,
      date: p.dailyRow.date,
      imported: true,
      ...(p.already ? { skipped: "rodada ja existia" } : { dailyLogId: logId }),
      errorCount: p.errors.length,
    };
    await saveState(state);
    onProgress(`Gravado ${p.dailyRow.date} — ${p.dailyRow.notes}`);
  }

  return { nLogs, nErrors, nRepeats };
}
