// Config do dashboard (gerado por dev/build-extension.mjs — nao editar a mao).
export const SUPABASE_URL = "https://kiogkgwuxuyljvfxbnez.supabase.co";
export const SUPABASE_ANON = "sb_publishable_Nt5ypm8o3GZ_DsFR1RmRgQ_VNsXz6t7";
export const SITE_URL = "https://residencia-cyan.vercel.app";
