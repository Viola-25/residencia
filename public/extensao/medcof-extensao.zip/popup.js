const $ = (id) => document.getElementById(id);
const btnPreview = $("preview");
const btnCommit = $("commit");
const logEl = $("log");
const resEl = $("resultado");
const metaEl = $("meta");

function setLog(msg) {
  logEl.textContent = msg;
}

function busy(on) {
  btnPreview.disabled = on;
  btnCommit.disabled = on;
}

function renderTable(rows) {
  if (!rows?.length) {
    resEl.innerHTML = "";
    return;
  }
  const trs = rows
    .map(
      (r) => `<tr>
        <td>${r.date.slice(5)}</td>
        <td>${r.questoes}q · ${r.hit}%</td>
        <td>${r.erros} erro${r.erros === 1 ? "" : "s"}</td>
        <td class="${r.jaExiste ? "skip" : ""}">${r.jaExiste ? "já existe" : "novo"}</td>
      </tr>`,
    )
    .join("");
  resEl.innerHTML = `<table><thead><tr><th>Data</th><th>Questões</th><th>Erros</th><th></th></tr></thead><tbody>${trs}</tbody></table>`;
}

async function refreshMeta() {
  const info = await chrome.runtime.sendMessage({ type: "info" });
  if (!info?.ok) return;
  metaEl.textContent = `${info.exames} testes no estado · sessão do site: ${info.temSessao ? "capturada" : "não"}`;
  if (info.lastLog && logEl.textContent === "Pronto.") setLog(info.lastLog);
}

async function run(commit) {
  busy(true);
  resEl.innerHTML = "";
  setLog(commit ? "Sincronizando..." : "Verificando...");
  try {
    const r = await chrome.runtime.sendMessage({ type: "run", commit });
    if (!r?.ok) {
      setLog("Erro: " + (r?.error || "desconhecido"));
      return;
    }
    if (r.nadaNovo) {
      setLog("Nada novo. Dashboard já está em dia.");
      return;
    }
    renderTable(r.plan);
    if (commit) {
      setLog(`Gravado: ${r.nLogs} rodada(s), ${r.nErrors} erro(s) novo(s), ${r.nRepeats || 0} reincidência(s).`);
      setTimeout(() => chrome.tabs.create({ url: "https://residencia-cyan.vercel.app/desempenho" }), 600);
    } else {
      const total = r.plan.reduce((s, p) => s + p.questoes, 0);
      const erros = r.plan.reduce((s, p) => s + p.erros, 0);
      const reinc = r.plan.reduce((s, p) => s + (p.reincidencias || 0), 0);
      setLog(`Prévia: ${r.plan.length} teste(s), ${total} questões, ${erros} erro(s) novo(s), ${reinc} reincidência(s). Clique em Sincronizar para gravar.`);
    }
    refreshMeta();
  } finally {
    busy(false);
  }
}

btnPreview.addEventListener("click", () => run(false));
btnCommit.addEventListener("click", () => run(true));

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "log") setLog(msg.msg);
});

refreshMeta();
