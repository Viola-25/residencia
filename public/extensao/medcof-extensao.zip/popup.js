const $ = (id) => document.getElementById(id);
const btnPreview = $("preview");
const btnCommit = $("commit");
const logEl = $("log");
const resEl = $("resultado");
const metaEl = $("meta");
const windowEl = $("window");
const WINDOW_OPTIONS = [7, 14, 30];
const DEFAULT_WINDOW_DAYS = 7;

function setLog(msg) {
  logEl.textContent = msg;
}

function fmtDia(iso) {
  if (!iso) return "nunca";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "nunca" : d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
}

async function loadWindow() {
  const { windowDays } = await chrome.storage.local.get("windowDays");
  const dias = WINDOW_OPTIONS.includes(Number(windowDays)) ? Number(windowDays) : DEFAULT_WINDOW_DAYS;
  windowEl.value = String(dias);
}

function busy(on) {
  btnPreview.disabled = on;
  btnCommit.disabled = on;
}

function renderTable(rows) {
  const novos = (rows || []).filter((r) => !r.jaExiste);
  const existentes = (rows || []).length - novos.length;

  if (!novos.length) {
    resEl.innerHTML = existentes
      ? `<p class="skip" style="margin:10px 0 0;font-size:11px">${existentes} teste(s) já existiam. Nada novo para gravar.</p>`
      : "";
    return;
  }

  const trs = novos
    .map(
      (r) => `<tr>
        <td>${r.date.slice(5)}</td>
        <td>${r.questoes}q · ${r.hit}%</td>
        <td>${r.erros} erro${r.erros === 1 ? "" : "s"}</td>
      </tr>`,
    )
    .join("");
  const nota = existentes
    ? `<p class="skip" style="margin:6px 0 0;font-size:11px">+ ${existentes} teste(s) já existiam — não serão duplicados.</p>`
    : "";
  resEl.innerHTML = `<table><thead><tr><th>Data</th><th>Questões</th><th>Erros</th></tr></thead><tbody>${trs}</tbody></table>${nota}`;
}

async function refreshMeta() {
  const info = await chrome.runtime.sendMessage({ type: "info" });
  if (!info?.ok) return;
  metaEl.textContent = `${info.exames} testes · v${info.versao || "?"} · ${info.windowDays || DEFAULT_WINDOW_DAYS}d · sync: ${fmtDia(info.lastSyncAt)} · sessão: ${info.temSessao ? "ok" : "não"}`;
  if (info.lastLog && logEl.textContent === "Pronto.") setLog(info.lastLog);
}

async function run(commit) {
  busy(true);
  resEl.innerHTML = "";
  setLog(commit ? "Sincronizando..." : "Verificando...");
  try {
    const dias = Number(windowEl.value) || DEFAULT_WINDOW_DAYS;
    const r = await chrome.runtime.sendMessage({ type: "run", commit, windowDays: dias });
    if (!r?.ok) {
      setLog("Erro: " + (r?.error || "desconhecido"));
      return;
    }
    if (r.nadaNovo) {
      setLog(`Nada novo na janela de ${r.windowDays || dias} dias.`);
      refreshMeta();
      return;
    }
    renderTable(r.plan);
    const novos = r.plan.filter((p) => !p.jaExiste);
    const jaExiste = r.plan.length - novos.length;
    const rest = r.remaining > 0 ? ` Restam ${r.remaining} testes.` : "";
    const jaTxt = jaExiste ? ` ${jaExiste} teste(s) já existiam.` : "";
    const janelaTxt = r.rangeStart ? ` Janela: ${r.windowDays}d desde ${fmtDia(r.rangeStart)}.` : "";

    if (commit) {
      if (r.nLogs === 0 && r.nErrors === 0) {
        setLog(`Nada novo para gravar.${jaTxt}${rest}${janelaTxt}`);
      } else {
        setLog(
          `Gravado: ${r.nLogs} rodada(s), ${r.nErrors} erro(s) novo(s), ${r.nRepeats || 0} reincidência(s).${jaTxt}${rest}${janelaTxt}`,
        );
      }
      if (!r.remaining && r.nLogs > 0) {
        setTimeout(() => chrome.tabs.create({ url: "https://residencia-cyan.vercel.app/desempenho" }), 600);
      }
    } else if (!novos.length) {
      setLog(`Prévia: nada novo para gravar.${jaTxt}${rest}${janelaTxt}`);
    } else {
      const total = novos.reduce((s, p) => s + p.questoes, 0);
      const erros = novos.reduce((s, p) => s + p.erros, 0);
      const reinc = novos.reduce((s, p) => s + (p.reincidencias || 0), 0);
      setLog(
        `Prévia: ${novos.length} teste(s) novo(s), ${total} questões, ${erros} erro(s) novo(s), ${reinc} reincidência(s).${jaTxt}${rest}${janelaTxt} Clique em Sincronizar para gravar.`,
      );
    }
    refreshMeta();
  } finally {
    busy(false);
  }
}

btnPreview.addEventListener("click", () => run(false));
btnCommit.addEventListener("click", () => run(true));
windowEl.addEventListener("change", async () => {
  await chrome.storage.local.set({ windowDays: Number(windowEl.value) });
  refreshMeta();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "log") setLog(msg.msg);
});

loadWindow().then(refreshMeta);
